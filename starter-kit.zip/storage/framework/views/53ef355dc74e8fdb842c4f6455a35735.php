<?php
$customizerHidden = 'customizer-hide';
$configData = Helper::appClasses();
?>



<?php $__env->startSection('title', 'Verify Email'); ?>

<?php $__env->startSection('page-style'); ?>
  
  <link rel="stylesheet" href="<?php echo e(asset(mix('assets/vendor/css/pages/page-auth.css'))); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="authentication-wrapper authentication-basic px-4">
  <div class="authentication-inner py-4">

    <!-- Logo -->
    <div class="app-brand mb-4">
      <a href="<?php echo e(url('/')); ?>" class="app-brand-link">
        <span class="app-brand-logo demo"><?php echo $__env->make('_partials.macros',['height'=>20,'withbg' => "fill: #fff;"], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?></span>
      </a>
    </div>
    <!-- /Logo -->

    <!-- Verify Email -->
    <div class="card">
      <div class="card-body">
        <h3 class="mb-1">Verify your email ✉️</h3>

        <?php if(session('status') == 'verification-link-sent'): ?>
        <div class="alert alert-success" role="alert">
          <div class="alert-body">
            A new verification link has been sent to the email address you provided during registration.
          </div>
        </div>
        <?php endif; ?>
        <p class="text-start">
          Account activation link sent to your email address: <span class="fw-medium"><?php echo e(Auth::user()->email); ?></span> Please follow the link inside to continue.
        </p>
        <div class="mt-4 d-flex flex-column justify-content-between gap-2">
          <form method="POST" action="<?php echo e(route('verification.send')); ?>">
            <?php echo csrf_field(); ?>
            <button type="submit" class="w-100 btn btn-label-secondary">
              click here to request another
            </button>
          </form>

            <form method="POST" action="<?php echo e(route('logout')); ?>">
              <?php echo csrf_field(); ?>

            <button type="submit" class="w-100 btn btn-danger">
              Log Out
            </button>
          </form>
        </div>
      </div>
    </div>
    <!-- /Verify Email -->
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/blankLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\vuexy\html-laravel\starter-kit\resources\views/auth/verify-email.blade.php ENDPATH**/ ?>