<button <?php echo e($attributes->merge(['type' => 'submit', 'class' => 'btn btn-primary text-uppercase'])); ?>>
  <?php echo e($slot); ?>

</button>
<?php /**PATH C:\xampp\htdocs\vuexy\html-laravel\starter-kit\resources\views/components/button.blade.php ENDPATH**/ ?>