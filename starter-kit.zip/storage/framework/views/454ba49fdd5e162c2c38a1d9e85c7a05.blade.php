<?php extract(collect($attributes->getAttributes())->mapWithKeys(function ($value, $key) { return [Illuminate\Support\Str::camel(str_replace([':', '.'], ' ', $key)) => $value]; })->all(), EXTR_SKIP); ?>
@props(['href','onclick'])
<x-dropdown-link :href="$href" :onclick="$onclick" >

{{ $slot ?? "" }}
</x-dropdown-link>