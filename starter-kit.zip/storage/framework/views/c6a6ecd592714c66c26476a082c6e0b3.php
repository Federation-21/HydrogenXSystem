<?php echo e($slot); ?>

<?php /**PATH C:\xampp\htdocs\vuexy\html-laravel\starter-kit\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>