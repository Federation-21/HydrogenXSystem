<div class="card">
  <h5 class="card-header">
    <?php echo e($title); ?>

  </h5>
  <div class="card-body">
    <p class="card-text text-muted">
      <?php echo e($description); ?>

    </p>
    <?php echo e($content); ?>

  </div>
</div>
<?php /**PATH C:\xampp\htdocs\vuexy\html-laravel\starter-kit\resources\views/components/action-section.blade.php ENDPATH**/ ?>