<?php
$configData = Helper::appClasses();
?>



<?php $__env->startSection('title', 'Page 2'); ?>

<?php $__env->startSection('content'); ?>
<h4>Page 2</h4>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/layoutMaster', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\vuexy\html-laravel\starter-kit\resources\views/content/pages/pages-page2.blade.php ENDPATH**/ ?>