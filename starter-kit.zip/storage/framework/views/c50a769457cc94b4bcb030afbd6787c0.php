<button <?php echo e($attributes->merge(['type' => 'button', 'class' => 'btn btn-label-secondary text-uppercase'])); ?>>
  <?php echo e($slot); ?>

</button>
<?php /**PATH C:\xampp\htdocs\vuexy\html-laravel\starter-kit\resources\views/components/secondary-button.blade.php ENDPATH**/ ?>